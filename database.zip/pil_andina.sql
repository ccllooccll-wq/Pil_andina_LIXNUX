-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-06-2026 a las 20:01:36
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pil_andina`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_movimiento` (IN `p_id_inventario` INT, IN `p_tipo` VARCHAR(10), IN `p_cantidad` INT, IN `p_motivo` VARCHAR(120), IN `p_id_usuario` INT)   BEGIN
    DECLARE v_stock INT;

    SELECT cantidad_actual INTO v_stock
    FROM inventario WHERE id_inventario = p_id_inventario FOR UPDATE;

    IF p_tipo = 'Salida' AND v_stock < p_cantidad THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock insuficiente para la salida solicitada';
    END IF;

    IF p_tipo = 'Entrada' THEN
        UPDATE inventario SET cantidad_actual = cantidad_actual + p_cantidad
        WHERE id_inventario = p_id_inventario;
    ELSE
        UPDATE inventario SET cantidad_actual = cantidad_actual - p_cantidad
        WHERE id_inventario = p_id_inventario;
    END IF;

    INSERT INTO movimiento (id_inventario, tipo_movimiento, cantidad, motivo, id_usuario)
    VALUES (p_id_inventario, p_tipo, p_cantidad, p_motivo, p_id_usuario);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_rotacion_producto` (IN `p_anio` INT, IN `p_mes` INT)   BEGIN
    SELECT  p.nombre_comercial AS producto,
            p.presentacion,
            SUM(CASE WHEN m.tipo_movimiento='Salida'
                     AND YEAR(m.fecha_movimiento)=p_anio
                     AND MONTH(m.fecha_movimiento)=p_mes
                     THEN m.cantidad ELSE 0 END) AS salidas_mes_actual,
            SUM(CASE WHEN m.tipo_movimiento='Salida'
                     AND ( (p_mes=1 AND YEAR(m.fecha_movimiento)=p_anio-1 AND MONTH(m.fecha_movimiento)=12)
                        OR (p_mes>1 AND YEAR(m.fecha_movimiento)=p_anio AND MONTH(m.fecha_movimiento)=p_mes-1) )
                     THEN m.cantidad ELSE 0 END) AS salidas_mes_anterior
    FROM producto p
    JOIN inventario i ON i.id_producto  = p.id_producto
    JOIN movimiento m ON m.id_inventario = i.id_inventario
    GROUP BY p.nombre_comercial, p.presentacion;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `id_log` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `accion` varchar(20) NOT NULL,
  `tabla_afectada` varchar(40) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `auditoria`
--

INSERT INTO `auditoria` (`id_log`, `id_usuario`, `accion`, `tabla_afectada`, `descripcion`, `fecha_hora`) VALUES
(1, 1, 'LOGIN', 'usuario', 'Inicio de sesion admin', '2026-06-05 00:02:54'),
(2, 2, 'LOGIN', 'usuario', 'Inicio de sesion gerente', '2026-06-05 00:02:54'),
(3, 1, 'INSERT', 'producto', 'Alta producto PAC355', '2026-06-05 00:02:54'),
(4, 1, 'INSERT', 'lote', 'Alta lote L-PAC355-001', '2026-06-05 00:02:54'),
(5, 2, 'SELECT', 'inventario', 'Consulta de stock', '2026-06-05 00:02:54'),
(6, 3, 'LOGIN', 'usuario', 'Inicio de sesion distribuidor', '2026-06-05 00:02:54'),
(7, 1, 'UPDATE', 'producto', 'Cambio de precio', '2026-06-05 00:02:54'),
(8, 2, 'SELECT', 'pedido', 'Consulta de pedidos pendientes', '2026-06-05 00:02:54'),
(9, 1, 'INSERT', 'distribuidor', 'Alta distribuidor Andina', '2026-06-05 00:02:54'),
(10, 1, 'DELETE', 'detalle_pedido', 'Eliminacion linea de pedido', '2026-06-05 00:02:54'),
(11, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 01:26:20'),
(12, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 01:27:51'),
(13, 2, 'LOGIN', 'usuario', 'Inicio de sesion: gerente@pilandina.bo', '2026-06-05 01:27:59'),
(14, 2, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 01:28:09'),
(15, 3, 'LOGIN', 'usuario', 'Inicio de sesion: distri@pilandina.bo', '2026-06-05 01:28:16'),
(16, 3, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 01:44:02'),
(17, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 01:44:11'),
(18, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 02:03:00'),
(19, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 02:03:42'),
(20, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 02:09:54'),
(21, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 02:10:00'),
(22, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 02:42:32'),
(23, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 02:42:39'),
(24, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 02:42:42'),
(25, 2, 'LOGIN', 'usuario', 'Inicio de sesion: gerente@pilandina.bo', '2026-06-05 02:42:52'),
(26, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 03:04:08'),
(27, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 03:04:18'),
(28, 2, 'LOGIN', 'usuario', 'Inicio de sesion: gerente@pilandina.bo', '2026-06-05 03:04:24'),
(29, 2, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 03:06:44'),
(30, 3, 'LOGIN', 'usuario', 'Inicio de sesion: distri@pilandina.bo', '2026-06-05 03:06:51'),
(31, 3, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 03:09:01'),
(32, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 03:09:06'),
(33, 2, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 03:18:14'),
(34, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 03:25:19'),
(35, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 12:32:44'),
(36, 1, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 13:06:30'),
(37, 2, 'LOGIN', 'usuario', 'Inicio de sesion: gerente@pilandina.bo', '2026-06-05 13:06:39'),
(38, 2, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 13:08:22'),
(39, 3, 'LOGIN', 'usuario', 'Inicio de sesion: distri@pilandina.bo', '2026-06-05 13:08:29'),
(40, 3, 'LOGOUT', 'usuario', 'Cierre de sesion', '2026-06-05 13:10:27'),
(41, 1, 'LOGIN', 'usuario', 'Inicio de sesion: admin@pilandina.bo', '2026-06-05 13:10:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bodega`
--

CREATE TABLE `bodega` (
  `id_bodega` int(11) NOT NULL,
  `id_planta` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tipo` enum('Producto Terminado','Insumos','Refrigerado') NOT NULL,
  `ubicacion_fisica` varchar(80) DEFAULT NULL,
  `capacidad_maxima` int(11) NOT NULL,
  `temperatura_almacenamiento` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `bodega`
--

INSERT INTO `bodega` (`id_bodega`, `id_planta`, `nombre`, `tipo`, `ubicacion_fisica`, `capacidad_maxima`, `temperatura_almacenamiento`) VALUES
(1, 1, 'Bodega PT La Paz', 'Producto Terminado', 'Galpon A', 100000, 18.00),
(2, 1, 'Bodega Refrig La Paz', 'Refrigerado', 'Camara 1', 30000, 4.00),
(3, 1, 'Bodega Insumos La Paz', 'Insumos', 'Galpon B', 50000, 20.00),
(4, 2, 'Bodega PT Cbba', 'Producto Terminado', 'Galpon A', 90000, 18.00),
(5, 2, 'Bodega Refrig Cbba', 'Refrigerado', 'Camara 1', 25000, 4.00),
(6, 2, 'Bodega Insumos Cbba', 'Insumos', 'Galpon B', 40000, 20.00),
(7, 3, 'Bodega PT Santa Cruz', 'Producto Terminado', 'Galpon A', 120000, 18.00),
(8, 3, 'Bodega Refrig SC', 'Refrigerado', 'Camara 1', 35000, 4.00),
(9, 3, 'Bodega Insumos SC', 'Insumos', 'Galpon B', 60000, 20.00),
(10, 1, 'Bodega Despacho La Paz', 'Producto Terminado', 'Anden 1', 20000, 18.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `control_calidad`
--

CREATE TABLE `control_calidad` (
  `id_control` int(11) NOT NULL,
  `id_lote` int(11) NOT NULL,
  `resultado` enum('Aprobado','Rechazado') NOT NULL,
  `tecnico_responsable` varchar(80) NOT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `fecha_control` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `control_calidad`
--

INSERT INTO `control_calidad` (`id_control`, `id_lote`, `resultado`, `tecnico_responsable`, `observaciones`, `fecha_control`) VALUES
(1, 1, 'Aprobado', 'Ing. Mamani', 'Parametros normales', '2026-01-11'),
(2, 2, 'Aprobado', 'Ing. Mamani', 'OK', '2026-01-13'),
(3, 3, 'Aprobado', 'Ing. Choque', 'OK', '2026-02-02'),
(4, 4, 'Aprobado', 'Ing. Choque', 'OK', '2026-02-06'),
(5, 5, 'Rechazado', 'Ing. Mamani', 'Exceso de espuma', '2026-02-11'),
(6, 6, 'Aprobado', 'Ing. Rojas', 'OK', '2026-03-02'),
(7, 7, 'Aprobado', 'Ing. Rojas', 'OK', '2026-03-04'),
(8, 8, 'Aprobado', 'Ing. Choque', 'OK', '2026-03-11'),
(9, 9, 'Aprobado', 'Ing. Mamani', 'OK', '2026-03-16'),
(10, 10, 'Aprobado', 'Ing. Rojas', 'OK', '2026-03-21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedido`
--

CREATE TABLE `detalle_pedido` (
  `id_detalle` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) GENERATED ALWAYS AS (`cantidad` * `precio_unitario`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `detalle_pedido`
--

INSERT INTO `detalle_pedido` (`id_detalle`, `id_pedido`, `id_producto`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 1, 500, 7.50),
(2, 1, 2, 300, 12.00),
(3, 2, 3, 400, 11.50),
(4, 3, 4, 200, 13.00),
(5, 4, 5, 150, 9.00),
(6, 5, 6, 250, 10.50),
(7, 6, 7, 300, 10.00),
(8, 7, 8, 200, 9.50),
(9, 8, 9, 150, 8.00),
(10, 9, 10, 150, 5.50),
(11, 10, 1, 600, 7.50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distribuidor`
--

CREATE TABLE `distribuidor` (
  `id_distribuidor` int(11) NOT NULL,
  `nit` varchar(20) NOT NULL,
  `razon_social` varchar(120) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `ciudad` varchar(40) NOT NULL,
  `zona` varchar(60) DEFAULT NULL,
  `contacto` varchar(80) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `distribuidor`
--

INSERT INTO `distribuidor` (`id_distribuidor`, `nit`, `razon_social`, `direccion`, `ciudad`, `zona`, `contacto`, `telefono`, `correo`) VALUES
(1, '1023456789', 'Distribuidora Andina SRL', 'Av. 6 de Agosto 234', 'La Paz', 'Sur', 'Luis Perez', '77712345', 'andina@dist.bo'),
(2, '1023456790', 'Bebidas del Valle', 'Av. America 1200', 'Cochabamba', 'Norte', 'Marta Rios', '77723456', 'valle@dist.bo'),
(3, '1023456791', 'Comercial Oriente', 'Av. Banzer 3000', 'Santa Cruz', 'Este', 'Juan Vaca', '77734567', 'oriente@dist.bo'),
(4, '1023456792', 'El Alto Bebidas', 'Av. 6 de Marzo 500', 'El Alto', 'Ceja', 'Rosa Mamani', '77745678', 'elalto@dist.bo'),
(5, '1023456793', 'Distribuidora Sur', 'Calle Sucre 88', 'Tarija', 'Centro', 'Carlos Gil', '77756789', 'sur@dist.bo'),
(6, '1023456794', 'Mayorista Potosi', 'Av. Universitaria 10', 'Potosi', 'Centro', 'Ana Soto', '77767890', 'potosi@dist.bo'),
(7, '1023456795', 'Bebidas Oruro', 'Calle Bolivar 45', 'Oruro', 'Centro', 'Pedro Lima', '77778901', 'oruro@dist.bo'),
(8, '1023456796', 'Distribuidora Beni', 'Av. 9 de Abril 77', 'Trinidad', 'Centro', 'Sara Roca', '77789012', 'beni@dist.bo'),
(9, '1023456797', 'Comercial Chuquisaca', 'Calle Junin 23', 'Sucre', 'Centro', 'Mario Paz', '77790123', 'sucre@dist.bo'),
(10, '1023456798', 'Pando Bebidas', 'Av. Internacional 5', 'Cobija', 'Centro', 'Lia Suarez', '77701234', 'pando@dist.bo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `monto_total` decimal(12,2) NOT NULL,
  `estado_pago` enum('Pendiente','Pagado') NOT NULL DEFAULT 'Pendiente',
  `fecha_emision` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `id_pedido`, `monto_total`, `estado_pago`, `fecha_emision`) VALUES
(1, 1, 7350.00, 'Pagado', '2026-05-05'),
(2, 2, 4600.00, 'Pagado', '2026-05-08'),
(3, 3, 2600.00, 'Pendiente', '2026-05-10'),
(4, 4, 1350.00, 'Pendiente', '2026-05-11'),
(5, 6, 3000.00, 'Pagado', '2026-05-13'),
(6, 7, 1900.00, 'Pendiente', '2026-05-14'),
(7, 8, 1200.00, 'Pendiente', '2026-05-15'),
(8, 9, 825.00, 'Pendiente', '2026-05-16'),
(9, 10, 4500.00, 'Pagado', '2026-05-17'),
(10, 5, 2625.00, 'Pendiente', '2026-05-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_lote` int(11) NOT NULL,
  `id_bodega` int(11) NOT NULL,
  `cantidad_actual` int(11) NOT NULL DEFAULT 0,
  `fecha_actualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id_inventario`, `id_producto`, `id_lote`, `id_bodega`, `cantidad_actual`, `fecha_actualizacion`) VALUES
(1, 1, 1, 1, 18000, '2026-06-05 00:02:54'),
(2, 2, 2, 1, 14000, '2026-06-05 00:02:54'),
(3, 3, 3, 4, 11000, '2026-06-05 00:02:54'),
(4, 4, 4, 4, 9500, '2026-06-05 00:02:54'),
(5, 5, 5, 1, 300, '2026-06-05 00:02:54'),
(6, 6, 6, 7, 8500, '2026-06-05 00:02:54'),
(7, 7, 7, 7, 9000, '2026-06-05 00:02:54'),
(8, 8, 8, 4, 150, '2026-06-05 00:02:54'),
(9, 9, 9, 1, 5800, '2026-06-05 00:02:54'),
(10, 10, 10, 7, 4800, '2026-06-05 00:02:54');

--
-- Disparadores `inventario`
--
DELIMITER $$
CREATE TRIGGER `trg_control_stock` BEFORE UPDATE ON `inventario` FOR EACH ROW BEGIN
    IF NEW.cantidad_actual < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La cantidad en inventario no puede ser negativa';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lote`
--

CREATE TABLE `lote` (
  `id_lote` int(11) NOT NULL,
  `numero_lote` varchar(30) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_planta` int(11) NOT NULL,
  `fecha_produccion` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `cantidad_producida` int(11) NOT NULL
) ;

--
-- Volcado de datos para la tabla `lote`
--

INSERT INTO `lote` (`id_lote`, `numero_lote`, `id_producto`, `id_planta`, `fecha_produccion`, `fecha_vencimiento`, `cantidad_producida`) VALUES
(1, 'L-PAC355-001', 1, 1, '2026-01-10', '2026-07-10', 20000),
(2, 'L-PAC620-001', 2, 1, '2026-01-12', '2026-07-12', 15000),
(3, 'L-TAQ620-001', 3, 2, '2026-02-01', '2026-08-01', 12000),
(4, 'L-HUA620-001', 4, 2, '2026-02-05', '2026-08-05', 10000),
(5, 'L-BOC355-001', 5, 1, '2026-02-10', '2026-06-15', 8000),
(6, 'L-REA620-001', 6, 3, '2026-03-01', '2026-09-01', 9000),
(7, 'L-IMP620-001', 7, 3, '2026-03-03', '2026-09-03', 9500),
(8, 'L-POT620-001', 8, 2, '2026-03-10', '2026-06-20', 7000),
(9, 'L-COP1L-001', 9, 1, '2026-03-15', '2026-09-15', 6000),
(10, 'L-MAL355-001', 10, 3, '2026-03-20', '2026-06-10', 5000);

--
-- Disparadores `lote`
--
DELIMITER $$
CREATE TRIGGER `trg_audit_lote` AFTER INSERT ON `lote` FOR EACH ROW BEGIN
    INSERT INTO auditoria (id_usuario, accion, tabla_afectada, descripcion)
    VALUES (NULL, 'INSERT', 'lote', CONCAT('Nuevo lote ', NEW.numero_lote));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id_movimiento` int(11) NOT NULL,
  `id_inventario` int(11) NOT NULL,
  `tipo_movimiento` enum('Entrada','Salida','Traslado') NOT NULL,
  `id_bodega_destino` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `motivo` varchar(120) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha_movimiento` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `id_pedido` int(11) NOT NULL,
  `id_distribuidor` int(11) NOT NULL,
  `fecha_pedido` date NOT NULL DEFAULT curdate(),
  `fecha_entrega_requerida` date DEFAULT NULL,
  `estado` enum('Pendiente','Despachado','Entregado','Cancelado') NOT NULL DEFAULT 'Pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pedido`
--

INSERT INTO `pedido` (`id_pedido`, `id_distribuidor`, `fecha_pedido`, `fecha_entrega_requerida`, `estado`) VALUES
(1, 1, '2026-05-01', '2026-05-05', 'Entregado'),
(2, 2, '2026-05-03', '2026-05-08', 'Despachado'),
(3, 3, '2026-05-05', '2026-05-10', 'Pendiente'),
(4, 4, '2026-05-06', '2026-05-11', 'Pendiente'),
(5, 5, '2026-05-07', '2026-05-12', 'Cancelado'),
(6, 6, '2026-05-08', '2026-05-13', 'Entregado'),
(7, 7, '2026-05-09', '2026-05-14', 'Despachado'),
(8, 8, '2026-05-10', '2026-05-15', 'Pendiente'),
(9, 9, '2026-05-11', '2026-05-16', 'Pendiente'),
(10, 10, '2026-05-12', '2026-05-17', 'Entregado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planta`
--

CREATE TABLE `planta` (
  `id_planta` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `ciudad` varchar(40) NOT NULL,
  `ubicacion` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `planta`
--

INSERT INTO `planta` (`id_planta`, `nombre`, `ciudad`, `ubicacion`) VALUES
(1, 'Planta La Paz', 'La Paz', 'Mecapaca'),
(2, 'Planta Cochabamba', 'Cochabamba', 'Sacaba'),
(3, 'Planta Santa Cruz', 'Santa Cruz', 'Palmasola');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_producto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre_comercial` varchar(60) NOT NULL,
  `tipo` enum('Lager','Pilsener','Malta','Negra') NOT NULL,
  `presentacion` varchar(15) NOT NULL,
  `graduacion_alcoholica` decimal(4,2) NOT NULL,
  `precio_actual` decimal(10,2) NOT NULL,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `stock_maximo` int(11) NOT NULL DEFAULT 100000,
  `activo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `codigo`, `nombre_comercial`, `tipo`, `presentacion`, `graduacion_alcoholica`, `precio_actual`, `stock_minimo`, `stock_maximo`, `activo`) VALUES
(1, 'PAC355', 'Pacena', 'Lager', '355ml', 5.00, 7.50, 500, 50000, 1),
(2, 'PAC620', 'Pacena', 'Lager', '620ml', 5.00, 12.00, 400, 40000, 1),
(3, 'TAQ620', 'Taquina', 'Pilsener', '620ml', 4.80, 11.50, 300, 30000, 1),
(4, 'HUA620', 'Huari', 'Lager', '620ml', 5.20, 13.00, 300, 30000, 1),
(5, 'BOC355', 'Bock', 'Negra', '355ml', 6.00, 9.00, 200, 20000, 1),
(6, 'REA620', 'Real', 'Pilsener', '620ml', 5.00, 10.50, 250, 25000, 1),
(7, 'IMP620', 'Imperial', 'Lager', '620ml', 4.90, 10.00, 250, 25000, 1),
(8, 'POT620', 'Potosina', 'Pilsener', '620ml', 4.70, 9.50, 200, 20000, 1),
(9, 'COP1L', 'Copacabana', 'Malta', '1L', 0.50, 8.00, 150, 15000, 1),
(10, 'MAL355', 'Maltin', 'Malta', '355ml', 0.00, 5.50, 150, 15000, 1);

--
-- Disparadores `producto`
--
DELIMITER $$
CREATE TRIGGER `trg_audit_precio` AFTER UPDATE ON `producto` FOR EACH ROW BEGIN
    IF OLD.precio_actual <> NEW.precio_actual THEN
        INSERT INTO auditoria (id_usuario, accion, tabla_afectada, descripcion)
        VALUES (NULL, 'UPDATE', 'producto',
                CONCAT('Producto ', NEW.codigo, ': precio ', OLD.precio_actual,
                       ' -> ', NEW.precio_actual));
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre`, `descripcion`) VALUES
(1, 'Administrador', 'Acceso total al sistema'),
(2, 'Gerente', 'Reportes, dashboard y consultas gerenciales'),
(3, 'Distribuidor', 'Consulta de stock y gestion de sus pedidos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `correo`, `password_hash`, `id_rol`, `activo`, `fecha_creacion`) VALUES
(1, 'Admin General', 'admin@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 1, 1, '2026-06-05 00:02:54'),
(2, 'Maria Gerente', 'gerente@pilandina.bo', 'scrypt:32768:8:1$WeZMhnNKTkLwXvMq$a706204d51f1b5d859e092c152a2e48d1c8f59746f7e2aa62e599188b5817d37913beebcb4c28350d64d04bd0ce2c1ed8170172db15f36c33f4de5b0f76a22b7', 2, 1, '2026-06-05 00:02:54'),
(3, 'Carlos Distribuidor', 'distri@pilandina.bo', 'scrypt:32768:8:1$x4UI5DiLH7gRIJQe$061eb69b681627d3329b00d7b111ceee5172ce13fc52fe484c0380ab9749a16e7018e8e90d95c07f933069633e69fd49b39fcebfebdb144ce6c087f9887ac7f5', 3, 1, '2026-06-05 00:02:54'),
(4, 'Ana Lopez', 'ana@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 2, 1, '2026-06-05 00:02:54'),
(5, 'Jorge Ramirez', 'jorge@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 3, 1, '2026-06-05 00:02:54'),
(6, 'Lucia Vargas', 'lucia@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 2, 1, '2026-06-05 00:02:54'),
(7, 'Pedro Soto', 'pedro@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 3, 1, '2026-06-05 00:02:54'),
(8, 'Sofia Mendez', 'sofia@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 2, 1, '2026-06-05 00:02:54'),
(9, 'Raul Flores', 'raul@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 3, 1, '2026-06-05 00:02:54'),
(10, 'Elena Quispe', 'elena@pilandina.bo', 'scrypt:32768:8:1$FV4c3mIK1YbTDLr3$4e2b5a682ab1330a47bf90d76cce9c43be7a4af82394a9112e2c0308f412123bb8bfd7fa3532617c9bd4d3d081dc46abaea5f10512518a57683c3437edc658b4', 1, 1, '2026-06-05 00:02:54');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_bajo_stock`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_bajo_stock` (
`codigo` varchar(20)
,`producto` varchar(60)
,`presentacion` varchar(15)
,`stock_actual` decimal(32,0)
,`stock_minimo` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pedidos_pendientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pedidos_pendientes` (
`distribuidor` varchar(120)
,`ciudad` varchar(40)
,`id_pedido` int(11)
,`fecha_pedido` date
,`fecha_entrega_requerida` date
,`estado` enum('Pendiente','Despachado','Entregado','Cancelado')
,`monto_pedido` decimal(34,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_proximos_vencer`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_proximos_vencer` (
`numero_lote` varchar(30)
,`producto` varchar(60)
,`presentacion` varchar(15)
,`fecha_vencimiento` date
,`dias_restantes` int(7)
,`unidades` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_stock_por_planta`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_stock_por_planta` (
`planta` varchar(40)
,`codigo` varchar(20)
,`producto` varchar(60)
,`presentacion` varchar(15)
,`stock_total` decimal(32,0)
,`stock_minimo` int(11)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `v_bajo_stock`
--
DROP TABLE IF EXISTS `v_bajo_stock`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_bajo_stock`  AS SELECT `p`.`codigo` AS `codigo`, `p`.`nombre_comercial` AS `producto`, `p`.`presentacion` AS `presentacion`, sum(`i`.`cantidad_actual`) AS `stock_actual`, `p`.`stock_minimo` AS `stock_minimo` FROM (`producto` `p` join `inventario` `i` on(`i`.`id_producto` = `p`.`id_producto`)) GROUP BY `p`.`codigo`, `p`.`nombre_comercial`, `p`.`presentacion`, `p`.`stock_minimo` HAVING sum(`i`.`cantidad_actual`) <= `p`.`stock_minimo` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pedidos_pendientes`
--
DROP TABLE IF EXISTS `v_pedidos_pendientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pedidos_pendientes`  AS SELECT `d`.`razon_social` AS `distribuidor`, `d`.`ciudad` AS `ciudad`, `ped`.`id_pedido` AS `id_pedido`, `ped`.`fecha_pedido` AS `fecha_pedido`, `ped`.`fecha_entrega_requerida` AS `fecha_entrega_requerida`, `ped`.`estado` AS `estado`, coalesce(sum(`dp`.`subtotal`),0) AS `monto_pedido` FROM ((`pedido` `ped` join `distribuidor` `d` on(`d`.`id_distribuidor` = `ped`.`id_distribuidor`)) left join `detalle_pedido` `dp` on(`dp`.`id_pedido` = `ped`.`id_pedido`)) WHERE `ped`.`estado` in ('Pendiente','Despachado') GROUP BY `d`.`razon_social`, `d`.`ciudad`, `ped`.`id_pedido`, `ped`.`fecha_pedido`, `ped`.`fecha_entrega_requerida`, `ped`.`estado` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_proximos_vencer`
--
DROP TABLE IF EXISTS `v_proximos_vencer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_proximos_vencer`  AS SELECT `l`.`numero_lote` AS `numero_lote`, `p`.`nombre_comercial` AS `producto`, `p`.`presentacion` AS `presentacion`, `l`.`fecha_vencimiento` AS `fecha_vencimiento`, to_days(`l`.`fecha_vencimiento`) - to_days(curdate()) AS `dias_restantes`, sum(`i`.`cantidad_actual`) AS `unidades` FROM ((`lote` `l` join `producto` `p` on(`p`.`id_producto` = `l`.`id_producto`)) join `inventario` `i` on(`i`.`id_lote` = `l`.`id_lote`)) WHERE `l`.`fecha_vencimiento` between curdate() and curdate() + interval 30 day GROUP BY `l`.`numero_lote`, `p`.`nombre_comercial`, `p`.`presentacion`, `l`.`fecha_vencimiento` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_stock_por_planta`
--
DROP TABLE IF EXISTS `v_stock_por_planta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_stock_por_planta`  AS SELECT `pl`.`nombre` AS `planta`, `p`.`codigo` AS `codigo`, `p`.`nombre_comercial` AS `producto`, `p`.`presentacion` AS `presentacion`, sum(`i`.`cantidad_actual`) AS `stock_total`, `p`.`stock_minimo` AS `stock_minimo` FROM (((`inventario` `i` join `producto` `p` on(`p`.`id_producto` = `i`.`id_producto`)) join `bodega` `b` on(`b`.`id_bodega` = `i`.`id_bodega`)) join `planta` `pl` on(`pl`.`id_planta` = `b`.`id_planta`)) GROUP BY `pl`.`nombre`, `p`.`codigo`, `p`.`nombre_comercial`, `p`.`presentacion`, `p`.`stock_minimo` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `fk_audit_usuario` (`id_usuario`);

--
-- Indices de la tabla `bodega`
--
ALTER TABLE `bodega`
  ADD PRIMARY KEY (`id_bodega`),
  ADD KEY `fk_bodega_planta` (`id_planta`);

--
-- Indices de la tabla `control_calidad`
--
ALTER TABLE `control_calidad`
  ADD PRIMARY KEY (`id_control`),
  ADD UNIQUE KEY `id_lote` (`id_lote`);

--
-- Indices de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `fk_det_pedido` (`id_pedido`),
  ADD KEY `fk_det_producto` (`id_producto`);

--
-- Indices de la tabla `distribuidor`
--
ALTER TABLE `distribuidor`
  ADD PRIMARY KEY (`id_distribuidor`),
  ADD UNIQUE KEY `nit` (`nit`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`),
  ADD UNIQUE KEY `id_pedido` (`id_pedido`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id_inventario`),
  ADD UNIQUE KEY `uq_inv` (`id_producto`,`id_lote`,`id_bodega`),
  ADD KEY `fk_inv_lote` (`id_lote`),
  ADD KEY `fk_inv_bodega` (`id_bodega`);

--
-- Indices de la tabla `lote`
--
ALTER TABLE `lote`
  ADD PRIMARY KEY (`id_lote`),
  ADD UNIQUE KEY `numero_lote` (`numero_lote`),
  ADD KEY `fk_lote_producto` (`id_producto`),
  ADD KEY `fk_lote_planta` (`id_planta`),
  ADD KEY `idx_lote_vencimiento` (`fecha_vencimiento`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id_movimiento`),
  ADD KEY `fk_mov_inv` (`id_inventario`),
  ADD KEY `fk_mov_bodega` (`id_bodega_destino`),
  ADD KEY `fk_mov_usuario` (`id_usuario`),
  ADD KEY `idx_mov_fecha` (`fecha_movimiento`);

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `fk_pedido_dist` (`id_distribuidor`),
  ADD KEY `idx_pedido_estado` (`estado`);

--
-- Indices de la tabla `planta`
--
ALTER TABLE `planta`
  ADD PRIMARY KEY (`id_planta`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id_producto`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_producto_nombre` (`nombre_comercial`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `fk_usuario_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `bodega`
--
ALTER TABLE `bodega`
  MODIFY `id_bodega` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `control_calidad`
--
ALTER TABLE `control_calidad`
  MODIFY `id_control` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `distribuidor`
--
ALTER TABLE `distribuidor`
  MODIFY `id_distribuidor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id_inventario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `lote`
--
ALTER TABLE `lote`
  MODIFY `id_lote` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `planta`
--
ALTER TABLE `planta`
  MODIFY `id_planta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD CONSTRAINT `fk_audit_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `bodega`
--
ALTER TABLE `bodega`
  ADD CONSTRAINT `fk_bodega_planta` FOREIGN KEY (`id_planta`) REFERENCES `planta` (`id_planta`);

--
-- Filtros para la tabla `control_calidad`
--
ALTER TABLE `control_calidad`
  ADD CONSTRAINT `fk_control_lote` FOREIGN KEY (`id_lote`) REFERENCES `lote` (`id_lote`);

--
-- Filtros para la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD CONSTRAINT `fk_det_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_det_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`);

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `fk_factura_pedido` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `fk_inv_bodega` FOREIGN KEY (`id_bodega`) REFERENCES `bodega` (`id_bodega`),
  ADD CONSTRAINT `fk_inv_lote` FOREIGN KEY (`id_lote`) REFERENCES `lote` (`id_lote`),
  ADD CONSTRAINT `fk_inv_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`);

--
-- Filtros para la tabla `lote`
--
ALTER TABLE `lote`
  ADD CONSTRAINT `fk_lote_planta` FOREIGN KEY (`id_planta`) REFERENCES `planta` (`id_planta`),
  ADD CONSTRAINT `fk_lote_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`);

--
-- Filtros para la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD CONSTRAINT `fk_mov_bodega` FOREIGN KEY (`id_bodega_destino`) REFERENCES `bodega` (`id_bodega`),
  ADD CONSTRAINT `fk_mov_inv` FOREIGN KEY (`id_inventario`) REFERENCES `inventario` (`id_inventario`),
  ADD CONSTRAINT `fk_mov_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `fk_pedido_dist` FOREIGN KEY (`id_distribuidor`) REFERENCES `distribuidor` (`id_distribuidor`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
