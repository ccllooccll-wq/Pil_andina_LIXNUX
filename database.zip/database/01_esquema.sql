-- =====================================================================
-- PROYECTO: Sistema de Gestión de Inventario y Distribución - PIL ANDINA
-- Base de Datos 2 - Hito 4
-- Motor: MySQL 8.x  |  Normalización: 3FN
-- Archivo 01: Esquema (DDL) - Creación de base de datos y tablas
-- =====================================================================

DROP DATABASE IF EXISTS pil_andina;
CREATE DATABASE pil_andina CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pil_andina;

-- ---------------------------------------------------------------------
-- TABLA: rol
-- ---------------------------------------------------------------------
CREATE TABLE rol (
    id_rol      INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(30) NOT NULL UNIQUE,           -- Administrador, Gerente, Distribuidor
    descripcion VARCHAR(150)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: usuario
-- ---------------------------------------------------------------------
CREATE TABLE usuario (
    id_usuario     INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(80)  NOT NULL,
    correo         VARCHAR(120) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,              -- almacenado con hash (werkzeug)
    id_rol         INT NOT NULL,
    activo         BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: producto
-- ---------------------------------------------------------------------
CREATE TABLE producto (
    id_producto           INT AUTO_INCREMENT PRIMARY KEY,
    codigo                VARCHAR(20) NOT NULL UNIQUE,
    nombre_comercial      VARCHAR(60) NOT NULL,        -- Paceña, Taquiña, Huari...
    tipo                  ENUM('Lager','Pilsener','Malta','Negra') NOT NULL,
    presentacion          VARCHAR(15) NOT NULL,        -- 355ml, 620ml, 1L
    graduacion_alcoholica DECIMAL(4,2) NOT NULL,
    precio_actual         DECIMAL(10,2) NOT NULL,
    stock_minimo          INT NOT NULL DEFAULT 0,
    stock_maximo          INT NOT NULL DEFAULT 100000,
    activo                BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: planta
-- ---------------------------------------------------------------------
CREATE TABLE planta (
    id_planta INT AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(40) NOT NULL,
    ciudad    VARCHAR(40) NOT NULL,
    ubicacion VARCHAR(60) NOT NULL                     -- Mecapaca, Sacaba, Palmasola
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: bodega
-- ---------------------------------------------------------------------
CREATE TABLE bodega (
    id_bodega                  INT AUTO_INCREMENT PRIMARY KEY,
    id_planta                  INT NOT NULL,
    nombre                     VARCHAR(50) NOT NULL,
    tipo                       ENUM('Producto Terminado','Insumos','Refrigerado') NOT NULL,
    ubicacion_fisica           VARCHAR(80),
    capacidad_maxima           INT NOT NULL,
    temperatura_almacenamiento DECIMAL(5,2),           -- en grados Celsius
    CONSTRAINT fk_bodega_planta FOREIGN KEY (id_planta) REFERENCES planta(id_planta)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: lote
-- ---------------------------------------------------------------------
CREATE TABLE lote (
    id_lote            INT AUTO_INCREMENT PRIMARY KEY,
    numero_lote        VARCHAR(30) NOT NULL UNIQUE,
    id_producto        INT NOT NULL,
    id_planta          INT NOT NULL,                   -- planta de origen
    fecha_produccion   DATE NOT NULL,
    fecha_vencimiento  DATE NOT NULL,
    cantidad_producida INT NOT NULL,
    CONSTRAINT fk_lote_producto FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    CONSTRAINT fk_lote_planta   FOREIGN KEY (id_planta)   REFERENCES planta(id_planta),
    CONSTRAINT chk_lote_fechas  CHECK (fecha_vencimiento > fecha_produccion)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: control_calidad
-- ---------------------------------------------------------------------
CREATE TABLE control_calidad (
    id_control          INT AUTO_INCREMENT PRIMARY KEY,
    id_lote             INT NOT NULL UNIQUE,           -- 1:1 con lote
    resultado           ENUM('Aprobado','Rechazado') NOT NULL,
    tecnico_responsable VARCHAR(80) NOT NULL,
    observaciones       VARCHAR(255),
    fecha_control       DATE NOT NULL,
    CONSTRAINT fk_control_lote FOREIGN KEY (id_lote) REFERENCES lote(id_lote)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: inventario  (stock actual por producto + lote + bodega)
-- ---------------------------------------------------------------------
CREATE TABLE inventario (
    id_inventario       INT AUTO_INCREMENT PRIMARY KEY,
    id_producto         INT NOT NULL,
    id_lote             INT NOT NULL,
    id_bodega           INT NOT NULL,
    cantidad_actual     INT NOT NULL DEFAULT 0,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_inv_producto FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    CONSTRAINT fk_inv_lote     FOREIGN KEY (id_lote)     REFERENCES lote(id_lote),
    CONSTRAINT fk_inv_bodega   FOREIGN KEY (id_bodega)   REFERENCES bodega(id_bodega),
    CONSTRAINT uq_inv UNIQUE (id_producto, id_lote, id_bodega)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: movimiento  (kardex: entradas, salidas, traslados)
-- ---------------------------------------------------------------------
CREATE TABLE movimiento (
    id_movimiento    INT AUTO_INCREMENT PRIMARY KEY,
    id_inventario    INT NOT NULL,
    tipo_movimiento  ENUM('Entrada','Salida','Traslado') NOT NULL,
    id_bodega_destino INT,                              -- usado en traslados
    cantidad         INT NOT NULL,
    motivo           VARCHAR(120),
    id_usuario       INT NOT NULL,
    fecha_movimiento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mov_inv     FOREIGN KEY (id_inventario) REFERENCES inventario(id_inventario),
    CONSTRAINT fk_mov_bodega  FOREIGN KEY (id_bodega_destino) REFERENCES bodega(id_bodega),
    CONSTRAINT fk_mov_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: distribuidor
-- ---------------------------------------------------------------------
CREATE TABLE distribuidor (
    id_distribuidor INT AUTO_INCREMENT PRIMARY KEY,
    nit             VARCHAR(20) NOT NULL UNIQUE,
    razon_social    VARCHAR(120) NOT NULL,
    direccion       VARCHAR(150),
    ciudad          VARCHAR(40) NOT NULL,
    zona            VARCHAR(60),
    contacto        VARCHAR(80),
    telefono        VARCHAR(20),
    correo          VARCHAR(120)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: pedido
-- ---------------------------------------------------------------------
CREATE TABLE pedido (
    id_pedido               INT AUTO_INCREMENT PRIMARY KEY,
    id_distribuidor         INT NOT NULL,
    fecha_pedido            DATE NOT NULL DEFAULT (CURRENT_DATE),
    fecha_entrega_requerida DATE,
    estado                  ENUM('Pendiente','Despachado','Entregado','Cancelado') NOT NULL DEFAULT 'Pendiente',
    CONSTRAINT fk_pedido_dist FOREIGN KEY (id_distribuidor) REFERENCES distribuidor(id_distribuidor)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: detalle_pedido  (resuelve M:N entre pedido y producto)
-- ---------------------------------------------------------------------
CREATE TABLE detalle_pedido (
    id_detalle      INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido       INT NOT NULL,
    id_producto     INT NOT NULL,
    cantidad        INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal        DECIMAL(12,2) AS (cantidad * precio_unitario) STORED,
    CONSTRAINT fk_det_pedido   FOREIGN KEY (id_pedido)   REFERENCES pedido(id_pedido) ON DELETE CASCADE,
    CONSTRAINT fk_det_producto FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: factura
-- ---------------------------------------------------------------------
CREATE TABLE factura (
    id_factura   INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido    INT NOT NULL UNIQUE,                  -- 1:1 con pedido
    monto_total  DECIMAL(12,2) NOT NULL,
    estado_pago  ENUM('Pendiente','Pagado') NOT NULL DEFAULT 'Pendiente',
    fecha_emision DATE NOT NULL DEFAULT (CURRENT_DATE),
    CONSTRAINT fk_factura_pedido FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABLA: auditoria  (log de acciones del sistema)
-- ---------------------------------------------------------------------
CREATE TABLE auditoria (
    id_log         INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario     INT,
    accion         VARCHAR(20) NOT NULL,               -- INSERT, UPDATE, DELETE, LOGIN
    tabla_afectada VARCHAR(40),
    descripcion    VARCHAR(255),
    fecha_hora     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;
